export const MONGO_URI = 'mongodb://localhost:27017/fastfood_auth_db';
export const JWT_SECRET = "P#Gww!)]-,bCUl~N9bUH+CX3KEeZ[=)}DKSM$YW@42c&Om'5Aq";
export const JWT_EXPIRES = '1d';
export const APP_PORT = 8888;

export const REFRESH_SECRET="UKkyrsXh7VUm{I#-G36.s!N@jO0{}~IGf0+$3DfCH)r.r8wWK-";
export const REFRESH_EXPIRES = '1d';
